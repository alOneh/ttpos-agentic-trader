from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from collections.abc import Awaitable, Callable
from typing import Any, TypeAlias

logger = logging.getLogger(__name__)

Listener: TypeAlias = Callable[..., Any] | Callable[..., Awaitable[Any]]


class AsyncEventEmitter:
    """Lightweight EventEmitter port supporting both sync and async listeners.

    Listeners registered with :meth:`on` are kept indefinitely; with :meth:`once`
    they are removed after the first invocation. Async listeners are scheduled
    on the running loop with :func:`asyncio.create_task`; sync listeners are
    invoked inline. Exceptions in listeners are logged but do not interrupt
    the dispatch of other listeners.
    """

    def __init__(self) -> None:
        self._listeners: dict[str, list[tuple[Listener, bool]]] = defaultdict(list)

    def on(self, event: str, listener: Listener) -> Listener:
        self._listeners[event].append((listener, False))
        return listener

    def once(self, event: str, listener: Listener) -> Listener:
        self._listeners[event].append((listener, True))
        return listener

    def off(self, event: str, listener: Listener) -> None:
        self._listeners[event] = [(fn, once) for fn, once in self._listeners[event] if fn is not listener]

    def remove_all_listeners(self, event: str | None = None) -> None:
        if event is None:
            self._listeners.clear()
        else:
            self._listeners.pop(event, None)

    def listener_count(self, event: str) -> int:
        return len(self._listeners.get(event, ()))

    def emit(self, event: str, *args: Any, **kwargs: Any) -> None:
        listeners = self._listeners.get(event, ())
        if not listeners:
            return

        survivors: list[tuple[Listener, bool]] = []
        for fn, once in listeners:
            try:
                result = fn(*args, **kwargs)
            except Exception:
                logger.exception("Listener for event %r raised", event)
                if not once:
                    survivors.append((fn, once))
                continue

            if asyncio.iscoroutine(result):
                try:
                    loop = asyncio.get_running_loop()
                except RuntimeError:
                    logger.error(
                        "Async listener for event %r emitted outside a running loop; coroutine dropped",
                        event,
                    )
                    result.close()
                else:
                    task = loop.create_task(result)
                    task.add_done_callback(_log_task_exception(event))

            if not once:
                survivors.append((fn, once))

        self._listeners[event] = survivors


def _log_task_exception(event: str) -> Callable[[asyncio.Task[Any]], None]:
    def _cb(task: asyncio.Task[Any]) -> None:
        if task.cancelled():
            return
        exc = task.exception()
        if exc is not None:
            logger.error("Async listener for event %r raised", event, exc_info=exc)

    return _cb
