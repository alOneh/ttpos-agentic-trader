from __future__ import annotations

import math
import time
from typing import Any

from tradingview_api.exceptions import TradingViewError


def _now_ms() -> int:
    return int(time.time() * 1000)


BUILTIN_DEFAULTS: dict[str, dict[str, Any]] = {
    "Volume@tv-basicstudies-241": {
        "length": 20,
        "col_prev_close": False,
    },
    "VbPFixed@tv-basicstudies-241": {
        "rowsLayout": "Number Of Rows",
        "rows": 24,
        "volume": "Up/Down",
        "vaVolume": 70,
        "subscribeRealtime": False,
        "first_bar_time": math.nan,
        "last_bar_time": _now_ms(),
        "extendToRight": False,
        "mapRightBoundaryToBarStartTime": True,
    },
    "VbPFixed@tv-basicstudies-241!": {
        "rowsLayout": "Number Of Rows",
        "rows": 24,
        "volume": "Up/Down",
        "vaVolume": 70,
        "subscribeRealtime": False,
        "first_bar_time": math.nan,
        "last_bar_time": _now_ms(),
    },
    "VbPFixed@tv-volumebyprice-53!": {
        "rowsLayout": "Number Of Rows",
        "rows": 24,
        "volume": "Up/Down",
        "vaVolume": 70,
        "subscribeRealtime": False,
        "first_bar_time": math.nan,
        "last_bar_time": _now_ms(),
    },
    "VbPSessions@tv-volumebyprice-53": {
        "rowsLayout": "Number Of Rows",
        "rows": 24,
        "volume": "Up/Down",
        "vaVolume": 70,
        "extendPocRight": False,
    },
    "VbPSessionsRough@tv-volumebyprice-53!": {
        "volume": "Up/Down",
        "vaVolume": 70,
    },
    "VbPSessionsDetailed@tv-volumebyprice-53!": {
        "volume": "Up/Down",
        "vaVolume": 70,
        "subscribeRealtime": False,
        "first_visible_bar_time": math.nan,
        "last_visible_bar_time": _now_ms(),
    },
    "VbPVisible@tv-volumebyprice-53": {
        "rowsLayout": "Number Of Rows",
        "rows": 24,
        "volume": "Up/Down",
        "vaVolume": 70,
        "subscribeRealtime": False,
        "first_visible_bar_time": math.nan,
        "last_visible_bar_time": _now_ms(),
    },
}


class BuiltInIndicator:
    """Wrapper around a TradingView built-in indicator (Volume, VbP variants...).

    Construct with the full type string, e.g. ``Volume@tv-basicstudies-241``.
    Default options are auto-populated from the matching template.
    """

    def __init__(self, type: str = "") -> None:
        self._type = type
        self._options: dict[str, Any] = dict(BUILTIN_DEFAULTS.get(type, {}))

    @property
    def type(self) -> str:
        return self._type

    @property
    def options(self) -> dict[str, Any]:
        return self._options

    def set_option(self, key: str, value: Any, force: bool = False) -> None:
        """Update one option. Validates against the default template unless ``force=True``."""
        defaults = BUILTIN_DEFAULTS.get(self._type)
        if defaults is not None and not force:
            if key not in defaults:
                raise TradingViewError(f"Unknown option for {self._type!r}: {key!r}")
            expected = type(defaults[key])
            if not isinstance(value, expected) and not (
                expected is float and isinstance(value, int)
            ):
                raise TradingViewError(
                    f"Invalid type for option {key!r}: expected {expected.__name__}, got {type(value).__name__}"
                )
        self._options[key] = value

    def to_study_inputs(self) -> dict[str, Any]:
        """The WS ``create_study`` packet expects the bare options dict for built-ins."""
        return dict(self._options)
