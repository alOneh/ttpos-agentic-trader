from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from tradingview_api.exceptions import TradingViewError

PineInputType = Literal["text", "source", "integer", "float", "resolution", "bool", "color"]


_TYPE_VALIDATORS: dict[str, type] = {
    "text": str,
    "source": str,
    "integer": int,
    "float": (int, float),  # type: ignore[dict-item]
    "resolution": str,
    "bool": bool,
    "color": (int, str),  # type: ignore[dict-item]
}


@dataclass
class PineInput:
    """One configurable input of a Pine Script indicator."""

    name: str
    type: PineInputType
    value: Any = None
    inline: str | None = None
    internal_id: str | None = None
    tooltip: str | None = None
    is_hidden: bool = False
    is_fake: bool = False
    options: list[str] | None = None


@dataclass
class PineIndicator:
    """Wrapper around a Pine Script indicator definition.

    Returned by :func:`tradingview_api.http.get_indicator`. Modify inputs via
    :meth:`set_option` then attach to a chart with :meth:`ChartSession.study`.
    """

    pine_id: str
    pine_version: str = "last"
    description: str = ""
    short_description: str = ""
    script: str = ""
    inputs: dict[str, PineInput] = field(default_factory=dict)
    plots: dict[str, str] = field(default_factory=dict)

    @property
    def type(self) -> str:
        """Indicator type expected by the WS ``create_study`` packet."""
        return "Script@tv-scripting-101!"

    def set_option(self, key: str, value: Any) -> None:
        """Update one input value, looked up by ``in_KEY``, ``key``, ``inline`` or ``internalID``."""
        target_input = self._find_input(key)
        if target_input is None:
            raise TradingViewError(f"Unknown Pine input: {key!r}")

        validator = _TYPE_VALIDATORS.get(target_input.type)
        if validator is not None and not isinstance(value, validator):  # type: ignore[arg-type]
            expected = validator.__name__ if isinstance(validator, type) else "/".join(t.__name__ for t in validator)  # type: ignore[union-attr]
            raise TradingViewError(
                f"Invalid value for input {target_input.name!r}: expected {expected}, got {type(value).__name__}"
            )
        target_input.value = value

    def _find_input(self, key: str) -> PineInput | None:
        if key in self.inputs:
            return self.inputs[key]
        prefixed = f"in_{key}"
        if prefixed in self.inputs:
            return self.inputs[prefixed]
        for inp in self.inputs.values():
            if inp.inline == key or inp.internal_id == key:
                return inp
        return None

    def to_study_inputs(self) -> dict[str, Any]:
        """Serialize inputs in the format expected by the WS ``create_study`` packet."""
        result: dict[str, Any] = {
            "text": self.script,
            "pineId": self.pine_id,
            "pineVersion": self.pine_version,
        }
        for index, (key, inp) in enumerate(self.inputs.items()):
            value: Any = inp.value
            if inp.type == "color":
                value = index
            result[key] = {"v": value, "f": inp.is_fake, "t": inp.type}
        return result
