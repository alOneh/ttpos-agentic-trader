from __future__ import annotations

import asyncio
import logging
from typing import Any, Literal

from tradingview_api.client import TradingViewClient
from tradingview_api.http import (
    IndicatorSearchResult,
    SymbolSearchResult,
    get_indicator,
    search_indicator,
    search_market,
)
from tradingview_api.indicators.builtin import BuiltInIndicator
from tradingview_api.indicators.pine import PineIndicator
from tradingview_api.models.ohlcv import OHLCVResult
from tradingview_api.models.quote import QuoteData

logger = logging.getLogger(__name__)


async def fetch_ohlcv(
    symbol: str,
    *,
    timeframe: str = "60",
    n_bars: int = 500,
    to: int | None = None,
    adjustment: Literal["splits", "dividends"] = "splits",
    session: Literal["regular", "extended"] | None = None,
    currency: str | None = None,
    timeout: float = 30.0,
    client: TradingViewClient | None = None,
) -> OHLCVResult:
    """Fetch OHLCV history for ``symbol`` on ``timeframe`` and return a snapshot.

    Opens its own client if none is provided. Pass an existing client to share
    a connection across multiple calls (and keep it alive for streaming).
    """
    own_client = client is None
    client = client or TradingViewClient()
    try:
        if own_client:
            await client.connect()

        chart = client.chart_session()
        try:
            chart.set_market(
                symbol,
                timeframe=timeframe,
                range_=n_bars,
                to=to,
                adjustment=adjustment,
                session=session,
                currency=currency,
            )
            return await chart.wait_loaded(timeout=timeout)
        finally:
            chart.close()
    finally:
        if own_client:
            await client.close()


async def fetch_quote(
    symbol: str,
    *,
    fields: Literal["all", "price"] = "all",
    timeout: float = 10.0,
    client: TradingViewClient | None = None,
) -> QuoteData:
    """Fetch a single quote snapshot for ``symbol``."""
    own_client = client is None
    client = client or TradingViewClient()
    try:
        if own_client:
            await client.connect()

        session = client.quote_session(fields=fields)
        market = session.market(symbol)
        try:
            return await market.wait_loaded(timeout=timeout)
        finally:
            market.close()
            session.close()
    finally:
        if own_client:
            await client.close()


async def search_symbol(
    query: str,
    *,
    search_type: str = "",
    exchange: str | None = None,
    start: int = 0,
    limit: int | None = None,
) -> list[SymbolSearchResult]:
    """Search TradingView's symbol database (HTTP, no WS connection needed)."""
    results = await search_market(
        query, search_type=search_type, exchange=exchange, start=start
    )
    if limit is not None:
        return results[:limit]
    return results


async def search_indicators(query: str, *, limit: int | None = None) -> list[IndicatorSearchResult]:
    """Search public Pine Script indicators by keyword."""
    results = await search_indicator(query)
    if limit is not None:
        return results[:limit]
    return results


async def run_indicator(
    symbol: str,
    indicator: PineIndicator | BuiltInIndicator | str,
    *,
    timeframe: str = "60",
    n_bars: int = 500,
    pine_version: str = "last",
    inputs: dict[str, Any] | None = None,
    timeout: float = 30.0,
    client: TradingViewClient | None = None,
) -> dict[str, Any]:
    """Compute a Pine or built-in indicator on ``symbol`` and return its periods + OHLCV.

    ``indicator`` may be a :class:`PineIndicator`, a :class:`BuiltInIndicator`,
    or a Pine ID string (in which case the indicator metadata is fetched first).
    ``inputs`` lets you override Pine input values before running.
    """
    own_client = client is None
    client = client or TradingViewClient()
    try:
        if own_client:
            await client.connect()

        if isinstance(indicator, str):
            indicator = await get_indicator(
                indicator, pine_version, credentials=client.credentials
            )

        if inputs and isinstance(indicator, PineIndicator):
            for key, value in inputs.items():
                indicator.set_option(key, value)

        chart = client.chart_session()
        try:
            chart.set_market(symbol, timeframe=timeframe, range_=n_bars)
            study = chart.study(indicator)
            # Single shared timeout; without it, the call could wait up to 2x.
            async with asyncio.timeout(timeout):
                ohlcv, study_periods = await asyncio.gather(
                    chart.wait_loaded(timeout=None),
                    study.wait_loaded(timeout=None),
                )
            return {
                "ohlcv": ohlcv,
                "indicator_periods": study_periods,
                "indicator": indicator,
            }
        finally:
            chart.close()
    finally:
        if own_client:
            await client.close()
