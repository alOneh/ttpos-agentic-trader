from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any

from tradingview_api.exceptions import SessionError, TradingViewError
from tradingview_api.indicators.builtin import BuiltInIndicator
from tradingview_api.indicators.pine import PineIndicator
from tradingview_api.protocol import Packet
from tradingview_api.utils import gen_session_id

if TYPE_CHECKING:
    from tradingview_api.sessions.chart import ChartSession

logger = logging.getLogger(__name__)


class ChartStudy:
    """An indicator (Pine or built-in) attached to a :class:`ChartSession`.

    The study materialises plot values per timestamp into ``periods``. Awaiting
    :meth:`wait_loaded` returns once the server signals the study is ready.
    """

    STUDY_PREFIX = "st"
    STUDY_REF = "st1"

    def __init__(
        self,
        chart_session: ChartSession,
        indicator: PineIndicator | BuiltInIndicator,
    ) -> None:
        self._chart = chart_session
        self._indicator: PineIndicator | BuiltInIndicator = indicator
        self.study_id = gen_session_id(self.STUDY_PREFIX)
        self._periods: dict[int, dict[str, Any]] = {}
        self._loaded_event = asyncio.Event()
        self._closed = False
        self._plot_names = self._build_plot_names(indicator)

        chart_session._study_listeners[self.study_id] = self._on_packet
        chart_session.send(
            "create_study",
            [
                chart_session.session_id,
                self.study_id,
                self.STUDY_REF,
                "$prices",
                indicator.type,
                indicator.to_study_inputs(),
            ],
        )

    @property
    def indicator(self) -> PineIndicator | BuiltInIndicator:
        return self._indicator

    @property
    def is_loaded(self) -> bool:
        return self._loaded_event.is_set()

    @property
    def periods(self) -> list[dict[str, Any]]:
        """Plot values per period, newest first."""
        return sorted(self._periods.values(), key=lambda p: p["$time"], reverse=True)

    async def wait_loaded(self, timeout: float | None = 30.0) -> list[dict[str, Any]]:
        if timeout is None:
            await self._loaded_event.wait()
        else:
            await asyncio.wait_for(self._loaded_event.wait(), timeout=timeout)
        return self.periods

    def set_indicator(self, indicator: PineIndicator | BuiltInIndicator) -> None:
        if self._closed:
            raise TradingViewError("Study is closed")
        self._indicator = indicator
        self._periods = {}
        self._loaded_event.clear()
        self._plot_names = self._build_plot_names(indicator)
        self._chart.send(
            "modify_study",
            [
                self._chart.session_id,
                self.study_id,
                self.STUDY_REF,
                indicator.to_study_inputs(),
            ],
        )

    def remove(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._chart._study_listeners.pop(self.study_id, None)
        try:
            self._chart.send("remove_study", [self._chart.session_id, self.study_id])
        except Exception:
            logger.debug("Failed to send remove_study", exc_info=True)

    def _on_packet(self, packet: Packet) -> None:
        msg_type = packet.get("m")
        params = packet.get("p", [])

        if msg_type == "study_completed":
            self._loaded_event.set()
            return

        if msg_type == "study_error":
            self._chart._events.emit("error", SessionError(f"study_error: {params}", packet=packet))
            return

        if msg_type in ("du", "timescale_update") and len(params) >= 2:
            update = params[1]
            if not isinstance(update, dict):
                return
            study_payload = update.get(self.study_id)
            if not isinstance(study_payload, dict):
                return
            entries = study_payload.get("st", [])
            for entry in entries:
                if not isinstance(entry, dict):
                    continue
                values = entry.get("v")
                if not isinstance(values, list) or not values:
                    continue
                period: dict[str, Any] = {"$time": int(values[0])}
                for i, v in enumerate(values[1:]):
                    plot_name = self._plot_names.get(f"plot_{i}", f"plot_{i}")
                    period[plot_name] = v
                self._periods[period["$time"]] = period
            # Loaded is only signalled by an explicit `study_completed` packet.

    def _build_plot_names(self, indicator: PineIndicator | BuiltInIndicator) -> dict[str, str]:
        if isinstance(indicator, PineIndicator):
            return dict(indicator.plots)
        return {}
