from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import Callable, Iterable
from typing import TYPE_CHECKING, Any, Literal

from tradingview_api.events import AsyncEventEmitter
from tradingview_api.models.quote import QuoteData
from tradingview_api.protocol import Packet
from tradingview_api.sessions.base import BaseSession

if TYPE_CHECKING:
    from tradingview_api.client import TradingViewClient

logger = logging.getLogger(__name__)

PRICE_QUOTE_FIELDS: tuple[str, ...] = ("lp",)

ALL_QUOTE_FIELDS: tuple[str, ...] = (
    "base-currency-logoid", "ch", "chp", "currency-logoid",
    "currency_code", "current_session", "description",
    "exchange", "format", "fractional", "is_tradable",
    "language", "local_description", "logoid", "lp",
    "lp_time", "minmov", "minmove2", "original_name",
    "pricescale", "pro_name", "short_name", "type",
    "update_mode", "volume", "ask", "bid", "fundamentals",
    "high_price", "low_price", "open_price", "prev_close_price",
    "rch", "rchp", "rtc", "rtc_time", "status", "industry",
    "basic_eps_net_income", "beta_1_year", "market_cap_basic",
    "earnings_per_share_basic_ttm", "price_earnings_ttm",
    "sector", "dividends_yield", "timezone", "country_code",
    "provider_id",
)

FieldsPreset = Literal["all", "price"]
Listener = Callable[..., Any]


def _resolve_fields(
    fields: FieldsPreset | None = None,
    custom_fields: Iterable[str] | None = None,
) -> tuple[str, ...]:
    if custom_fields:
        return tuple(custom_fields)
    if fields == "price":
        return PRICE_QUOTE_FIELDS
    return ALL_QUOTE_FIELDS


def _symbol_key(symbol: str, session: str = "regular") -> str:
    """Build the TradingView symbol key, e.g. ``={"session":"regular","symbol":"BTC"}``."""
    payload = json.dumps({"session": session, "symbol": symbol}, separators=(",", ":"))
    return f"={payload}"


class QuoteSession(BaseSession):
    """Multiplexed real-time quote stream.

    Each :class:`QuoteMarket` created from this session subscribes to one
    symbol; multiple markets sharing the same symbol/session pair share the
    underlying subscription.
    """

    SESSION_PREFIX = "qs"

    def __init__(
        self,
        client: TradingViewClient,
        *,
        fields: FieldsPreset | None = "all",
        custom_fields: Iterable[str] | None = None,
    ) -> None:
        super().__init__(client)
        self._symbol_listeners: dict[str, list[QuoteMarket]] = {}
        resolved_fields = _resolve_fields(fields, custom_fields)
        self.send("quote_create_session", [self.session_id])
        self.send("quote_set_fields", [self.session_id, *resolved_fields])

    def market(self, symbol: str, *, session: str = "regular") -> QuoteMarket:
        """Subscribe to a symbol and return a :class:`QuoteMarket` to listen on."""
        return QuoteMarket(self, symbol, session_kind=session)

    def on_data(self, packet: Packet) -> None:
        msg_type = packet.get("m")
        params = packet.get("p", [])

        if msg_type == "quote_completed":
            symbol_key = params[1] if len(params) > 1 else None
            if isinstance(symbol_key, str):
                self._dispatch(symbol_key, packet)
            return

        if msg_type == "qsd":
            payload = params[1] if len(params) > 1 else {}
            symbol_key = payload.get("n") if isinstance(payload, dict) else None
            if isinstance(symbol_key, str):
                self._dispatch(symbol_key, packet)

    def _dispatch(self, symbol_key: str, packet: Packet) -> None:
        listeners = self._symbol_listeners.get(symbol_key)
        if not listeners:
            self.send("quote_remove_symbols", [self.session_id, symbol_key])
            return
        for listener in listeners:
            listener.handle(packet)

    def _add_listener(self, symbol_key: str, market: QuoteMarket) -> bool:
        first = symbol_key not in self._symbol_listeners
        self._symbol_listeners.setdefault(symbol_key, []).append(market)
        return first

    def _remove_listener(self, symbol_key: str, market: QuoteMarket) -> bool:
        listeners = self._symbol_listeners.get(symbol_key, [])
        if market in listeners:
            listeners.remove(market)
        if not listeners:
            self._symbol_listeners.pop(symbol_key, None)
            return True
        return False

    def close(self) -> None:
        if self.is_closed:
            return
        try:
            self.send("quote_delete_session", [self.session_id])
        except Exception:
            logger.debug("Failed to send quote_delete_session", exc_info=True)
        super().close()


class QuoteMarket:
    """One symbol subscription on a :class:`QuoteSession`.

    Holds the latest merged :class:`QuoteData`, emits ``data`` on every update,
    ``loaded`` when the initial ``quote_completed`` arrives, and ``error`` on
    server-side errors.
    """

    def __init__(
        self,
        session: QuoteSession,
        symbol: str,
        *,
        session_kind: str = "regular",
    ) -> None:
        self._session = session
        self.symbol = symbol
        self.session_kind = session_kind
        self._symbol_key = _symbol_key(symbol, session_kind)
        self._last_data = QuoteData()
        self._loaded_event = asyncio.Event()
        self._closed = False
        # Per-market emitter: callbacks registered here only fire for THIS market.
        # Two markets for the same symbol are independent listeners.
        self._events = AsyncEventEmitter()

        is_first = session._add_listener(self._symbol_key, self)
        if is_first:
            session.send("quote_add_symbols", [session.session_id, self._symbol_key])

    @property
    def last_data(self) -> QuoteData:
        return self._last_data

    @property
    def is_loaded(self) -> bool:
        return self._loaded_event.is_set()

    def on(self, event: str, listener: Listener) -> Listener:
        """Register a callback for ``event`` (``"data"``, ``"loaded"``, ``"error"``).

        Returns the listener so it can be used as a decorator::

            @market.on("data")
            def handler(quote): ...
        """
        return self._events.on(event, listener)

    def once(self, event: str, listener: Listener) -> Listener:
        return self._events.once(event, listener)

    def off(self, event: str, listener: Listener) -> None:
        self._events.off(event, listener)

    async def wait_loaded(self, timeout: float | None = None) -> QuoteData:
        """Wait for the server's ``quote_completed`` and return the snapshot."""
        if timeout is None:
            await self._loaded_event.wait()
        else:
            await asyncio.wait_for(self._loaded_event.wait(), timeout=timeout)
        return self._last_data

    def handle(self, packet: Packet) -> None:
        msg_type = packet.get("m")
        params = packet.get("p", [])

        if msg_type == "qsd":
            payload = params[1] if len(params) > 1 else {}
            status = payload.get("s")
            values = payload.get("v", {})
            if status == "ok":
                self._last_data = self._last_data.merged_with(values)
                self._events.emit("data", self._last_data)
            elif status == "error":
                self._events.emit("error", values)
            return

        if msg_type == "quote_completed":
            self._loaded_event.set()
            self._events.emit("loaded", self._last_data)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        # Drop all callbacks attached to this market so closing one market
        # never silently invalidates another's listeners.
        self._events.remove_all_listeners()
        was_last = self._session._remove_listener(self._symbol_key, self)
        if was_last and not self._session.is_closed:
            try:
                self._session.send(
                    "quote_remove_symbols",
                    [self._session.session_id, self._symbol_key],
                )
            except Exception:
                logger.debug("Failed to send quote_remove_symbols", exc_info=True)
