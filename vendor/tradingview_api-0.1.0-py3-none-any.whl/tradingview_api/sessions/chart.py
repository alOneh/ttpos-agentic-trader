from __future__ import annotations

import asyncio
import json
import logging
from typing import TYPE_CHECKING, Any, Literal

from tradingview_api.exceptions import SessionError, TradingViewError
from tradingview_api.models.ohlcv import MarketInfo, OHLCVResult, Period, merge_periods
from tradingview_api.protocol import Packet
from tradingview_api.sessions.base import BaseSession

if TYPE_CHECKING:
    from tradingview_api.client import TradingViewClient

logger = logging.getLogger(__name__)

Adjustment = Literal["splits", "dividends"]
SessionKind = Literal["regular", "extended"]


class ChartSession(BaseSession):
    """Chart session: load OHLCV data for a symbol on a given timeframe.

    Typical usage::

        chart = client.chart_session()
        chart.set_market("BINANCE:BTCEUR", timeframe="60", range_=500)
        result = await chart.wait_loaded()
        df = result.df

    The session keeps streaming updates after the initial load. Listen with
    ``chart.on("update", handler)`` to react to new candles.
    """

    SESSION_PREFIX = "cs"

    PRICE_SERIES_KEY = "$prices"
    DEFAULT_SERIES_REF = "s1"
    DEFAULT_TIMEFRAME = "240"
    DEFAULT_RANGE = 100

    def __init__(self, client: TradingViewClient) -> None:
        super().__init__(client)
        self._infos: MarketInfo | None = None
        self._periods: dict[int, Period] = {}
        self._series_index = 0
        self._series_created = False
        self._current_symbol: str | None = None
        self._current_timeframe: str = self.DEFAULT_TIMEFRAME
        self._symbol_loaded_event = asyncio.Event()
        self._series_loaded_event = asyncio.Event()
        self._study_listeners: dict[str, Any] = {}
        self._study_indexes: dict[int, int] = {}
        self.send("chart_create_session", [self.session_id])

    @property
    def info(self) -> MarketInfo | None:
        return self._infos

    @property
    def periods(self) -> list[Period]:
        return sorted(self._periods.values(), key=lambda p: p.time, reverse=True)

    def snapshot(self) -> OHLCVResult:
        """Return an immutable snapshot of the current periods + symbol info."""
        if self._infos is None or self._current_symbol is None:
            raise TradingViewError("No market loaded yet")
        return OHLCVResult(
            symbol=self._current_symbol,
            timeframe=self._current_timeframe,
            info=self._infos,
            periods=list(self._periods.values()),
        )

    async def wait_loaded(self, timeout: float | None = 30.0) -> OHLCVResult:
        """Wait for the symbol to resolve and the initial series to arrive."""
        async def _both() -> None:
            await self._symbol_loaded_event.wait()
            await self._series_loaded_event.wait()

        if timeout is None:
            await _both()
        else:
            await asyncio.wait_for(_both(), timeout=timeout)
        return self.snapshot()

    def set_market(
        self,
        symbol: str,
        *,
        timeframe: str = DEFAULT_TIMEFRAME,
        range_: int = DEFAULT_RANGE,
        to: int | None = None,
        adjustment: Adjustment = "splits",
        backadjustment: bool = False,
        session: SessionKind | None = None,
        currency: str | None = None,
    ) -> None:
        """Load (or switch to) a symbol on this chart session."""
        self._periods = {}
        self._symbol_loaded_event.clear()
        self._series_loaded_event.clear()
        self._current_symbol = symbol
        self._current_timeframe = timeframe

        symbol_init: dict[str, Any] = {
            "symbol": symbol,
            "adjustment": adjustment,
        }
        if backadjustment:
            symbol_init["backadjustment"] = "default"
        if session:
            symbol_init["session"] = session
        if currency:
            symbol_init["currency-id"] = currency

        self._series_index += 1
        symbol_payload = "=" + json.dumps(symbol_init, separators=(",", ":"))
        self.send(
            "resolve_symbol",
            [self.session_id, f"ser_{self._series_index}", symbol_payload],
        )
        self._set_series(timeframe, range_, to)

    def _set_series(self, timeframe: str, range_: int, reference: int | None) -> None:
        if not self._series_index:
            raise TradingViewError("Must set_market before set_series")

        calc_range: Any = range_ if reference is None else ["bar_count", reference, range_]

        msg_type = "modify_series" if self._series_created else "create_series"
        self._periods = {}
        self.send(
            msg_type,
            [
                self.session_id,
                self.PRICE_SERIES_KEY,
                self.DEFAULT_SERIES_REF,
                f"ser_{self._series_index}",
                timeframe,
                "" if self._series_created else calc_range,
            ],
        )
        self._series_created = True

    def fetch_more(self, count: int = 1) -> None:
        """Request ``count`` additional historical periods."""
        self.send("request_more_data", [self.session_id, self.PRICE_SERIES_KEY, count])

    def study(self, indicator: Any) -> Any:
        """Attach a :class:`PineIndicator` or :class:`BuiltInIndicator` to this chart."""
        from tradingview_api.sessions.study import ChartStudy

        return ChartStudy(self, indicator)

    def set_timezone(self, timezone: str) -> None:
        """Switch the chart's timezone (e.g. ``"Etc/UTC"``, ``"Europe/Paris"``)."""
        self._periods = {}
        self.send("switch_timezone", [self.session_id, timezone])

    def on_data(self, packet: Packet) -> None:
        msg_type = packet.get("m")
        params = packet.get("p", [])

        # Only route to a study listener if params[1] is a study ID (st_*).
        # Otherwise we'd masquerade ser_1 / symbol_keys as study packets.
        if (
            isinstance(params, list)
            and len(params) > 1
            and isinstance(params[1], str)
            and params[1].startswith("st_")
        ):
            study_handler = self._study_listeners.get(params[1])
            if study_handler is not None:
                study_handler(packet)
                return

        if msg_type == "symbol_resolved":
            self._handle_symbol_resolved(params)
            return

        if msg_type in ("timescale_update", "du"):
            self._handle_data_update(packet, params)
            return

        if msg_type == "symbol_error":
            self._events.emit("error", SessionError(f"symbol_error: {params}", packet=packet))
            return

        if msg_type == "series_error":
            self._events.emit("error", SessionError(f"series_error: {params}", packet=packet))
            return

        if msg_type == "critical_error":
            self._events.emit("error", SessionError(f"critical_error: {params}", packet=packet))
            return

        if msg_type == "series_completed":
            self._series_loaded_event.set()
            self._events.emit("series_loaded")
            return

    def _handle_symbol_resolved(self, params: list[Any]) -> None:
        if len(params) < 3:
            return
        series_id = params[1]
        infos_dict = params[2] if isinstance(params[2], dict) else {}
        self._infos = MarketInfo.model_validate({**infos_dict, "series_id": series_id})
        self._symbol_loaded_event.set()
        self._events.emit("symbol_loaded", self._infos)

    def _handle_data_update(self, packet: Packet, params: list[Any]) -> None:
        if len(params) < 2 or not isinstance(params[1], dict):
            return
        update_payload = params[1]
        changes: list[str] = []

        for key, value in update_payload.items():
            changes.append(key)
            if key == self.PRICE_SERIES_KEY:
                series_data = value if isinstance(value, dict) else {}
                entries = series_data.get("s", [])
                if entries:
                    for entry in entries:
                        if isinstance(entry, dict):
                            i, v = entry.get("i"), entry.get("v")
                            if isinstance(i, int) and isinstance(v, list) and v:
                                self._study_indexes[i] = int(v[0])
                    merge_periods(self._periods, [e for e in entries if isinstance(e, dict)])
                # series_loaded is only signalled by an explicit `series_completed`
                # packet (handled in on_data). Setting it here on the first `du` would
                # mark a partial batch as complete.
                continue

            study_handler = self._study_listeners.get(key)
            if study_handler is not None:
                study_handler(packet)

        self._events.emit("update", changes)

    def close(self) -> None:
        if self.is_closed:
            return
        try:
            self.send("chart_delete_session", [self.session_id])
        except Exception:
            logger.debug("Failed to send chart_delete_session", exc_info=True)
        super().close()
