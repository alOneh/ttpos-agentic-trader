from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

from tradingview_api.events import AsyncEventEmitter
from tradingview_api.protocol import Packet
from tradingview_api.utils import gen_session_id

if TYPE_CHECKING:
    from tradingview_api.client import TradingViewClient

logger = logging.getLogger(__name__)


class BaseSession(ABC):
    """Common scaffolding for QuoteSession / ChartSession.

    Subclasses register themselves on the parent client and dispatch incoming
    packets via :meth:`on_data`. Closing the session unregisters from the
    client and cancels pending waits.
    """

    SESSION_PREFIX: str = "ss"

    def __init__(self, client: TradingViewClient) -> None:
        self._client = client
        self.session_id = gen_session_id(self.SESSION_PREFIX)
        self._closed = False
        self._events = AsyncEventEmitter()
        self._client.register_session(self.session_id, self)

    @abstractmethod
    def on_data(self, packet: Packet) -> None:
        """Called by the client for each packet routed to this session."""

    def send(self, msg_type: str, params: list[Any]) -> None:
        if self._closed:
            raise RuntimeError(f"Session {self.session_id} is closed")
        self._client.send(msg_type, params)

    def close(self) -> None:
        """Idempotent. Subclasses should override to send the proper delete packet."""
        if self._closed:
            return
        self._closed = True
        self._client.unregister_session(self.session_id)

    @property
    def is_closed(self) -> bool:
        return self._closed

    def on(self, event: str, listener: Any) -> Any:
        return self._events.on(event, listener)

    def once(self, event: str, listener: Any) -> Any:
        return self._events.once(event, listener)

    def off(self, event: str, listener: Any) -> None:
        self._events.off(event, listener)

    def __enter__(self) -> BaseSession:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()


