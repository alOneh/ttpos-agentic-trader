from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass
from typing import Any

import httpx

from tradingview_api.exceptions import AuthError
from tradingview_api.utils import gen_auth_cookies

logger = logging.getLogger(__name__)

ANONYMOUS_TOKEN = "unauthorized_user_token"
DEFAULT_LOCATION = "https://www.tradingview.com/"
DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)
_MAX_REDIRECTS = 5
_AUTH_TOKEN_RX = re.compile(r'"auth_token":"(.*?)"')
_USER_ID_RX = re.compile(r'"id":([0-9]{1,10}),')
_USERNAME_RX = re.compile(r'"username":"(.*?)"')


@dataclass(frozen=True, slots=True)
class Credentials:
    """TradingView auth material.

    A blank ``Credentials()`` represents anonymous access; the WebSocket will
    use the ``unauthorized_user_token`` literal.
    """

    sessionid: str | None = None
    sessionid_sign: str | None = None
    auth_token: str | None = None

    @property
    def is_anonymous(self) -> bool:
        return not (self.sessionid or self.auth_token)

    @classmethod
    def from_env(cls, env: dict[str, str] | None = None) -> Credentials:
        env = env if env is not None else os.environ
        return cls(
            sessionid=env.get("TV_SESSIONID") or None,
            sessionid_sign=env.get("TV_SESSIONID_SIGN") or None,
            auth_token=env.get("TV_AUTH_TOKEN") or None,
        )

    @classmethod
    def from_browser(cls, browser: str = "chrome", domain: str = "tradingview.com") -> Credentials:
        """Read TradingView cookies from a local browser using ``rookiepy``."""
        try:
            import rookiepy
        except ImportError as exc:
            raise AuthError(
                "rookiepy is required to read browser cookies. "
                "Install with: uv sync --extra browser"
            ) from exc

        loader = getattr(rookiepy, browser, None)
        if loader is None:
            raise AuthError(f"Unsupported browser: {browser!r}")

        try:
            cookies = loader([domain])
        except Exception as exc:
            raise AuthError(f"Failed to read cookies from {browser}: {exc}") from exc

        sessionid = _find_cookie(cookies, "sessionid")
        sessionid_sign = _find_cookie(cookies, "sessionid_sign")
        if not sessionid:
            raise AuthError(f"No sessionid cookie found in {browser} for {domain}")
        return cls(sessionid=sessionid, sessionid_sign=sessionid_sign)


def resolve_credentials(
    *,
    sessionid: str | None = None,
    sessionid_sign: str | None = None,
    auth_token: str | None = None,
    use_env: bool = True,
) -> Credentials:
    """Build credentials, preferring explicit kwargs over env vars.

    Returns anonymous credentials if nothing is provided.
    """
    if sessionid or auth_token:
        return Credentials(sessionid=sessionid, sessionid_sign=sessionid_sign, auth_token=auth_token)
    if use_env:
        env_creds = Credentials.from_env()
        if not env_creds.is_anonymous:
            return env_creds
    return Credentials()


@dataclass(frozen=True, slots=True)
class UserInfo:
    """Minimal user metadata extracted from the TradingView account page."""

    id: int
    username: str | None
    auth_token: str


async def fetch_user_info(
    sessionid: str,
    sessionid_sign: str | None = None,
    *,
    location: str = DEFAULT_LOCATION,
    client: httpx.AsyncClient | None = None,
    user_agent: str = DEFAULT_USER_AGENT,
) -> UserInfo:
    """Resolve user id, username and ``auth_token`` from a TradingView session cookie.

    The site embeds these in the user account HTML page. Follows up to 5
    redirects manually to handle geo-routing (e.g. fr.tradingview.com).
    """
    headers = {
        "Cookie": gen_auth_cookies(sessionid, sessionid_sign),
        "User-Agent": user_agent,
        "Accept-Language": "en-US,en;q=0.9",
    }

    own_client = client is None
    http = client or httpx.AsyncClient(timeout=10.0, follow_redirects=False)
    try:
        current_location = location
        for _ in range(_MAX_REDIRECTS + 1):
            response = await http.get(current_location, headers=headers)
            text = response.text

            token_match = _AUTH_TOKEN_RX.search(text)
            if token_match:
                id_match = _USER_ID_RX.search(text)
                name_match = _USERNAME_RX.search(text)
                return UserInfo(
                    id=int(id_match.group(1)) if id_match else 0,
                    username=name_match.group(1) if name_match else None,
                    auth_token=token_match.group(1),
                )

            redirect = response.headers.get("location")
            if redirect and redirect != current_location:
                current_location = redirect
                continue

            break

        raise AuthError("Wrong or expired sessionid/signature (no auth_token in response)")
    finally:
        if own_client:
            await http.aclose()


async def fetch_auth_token(
    sessionid: str,
    sessionid_sign: str | None = None,
    *,
    location: str = DEFAULT_LOCATION,
    client: httpx.AsyncClient | None = None,
    user_agent: str = DEFAULT_USER_AGENT,
) -> str:
    """Convenience wrapper around :func:`fetch_user_info` returning just the token."""
    info = await fetch_user_info(
        sessionid,
        sessionid_sign,
        location=location,
        client=client,
        user_agent=user_agent,
    )
    return info.auth_token


def _find_cookie(cookies: list[dict[str, Any]], name: str) -> str | None:
    for c in cookies:
        if c.get("name") == name:
            value = c.get("value")
            return str(value) if value is not None else None
    return None
