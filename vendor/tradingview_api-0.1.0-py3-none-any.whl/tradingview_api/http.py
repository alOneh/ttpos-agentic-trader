from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

import httpx
from pydantic import BaseModel, ConfigDict, Field

from tradingview_api.auth import DEFAULT_USER_AGENT, Credentials
from tradingview_api.exceptions import TradingViewError
from tradingview_api.indicators.pine import PineIndicator, PineInput, PineInputType
from tradingview_api.utils import gen_auth_cookies

logger = logging.getLogger(__name__)

SYMBOL_SEARCH_URL = "https://symbol-search.tradingview.com/symbol_search/v3"
INDICATOR_SEARCH_URL = "https://www.tradingview.com/pubscripts-suggest-json"
INDICATOR_TRANSLATE_URL = "https://pine-facade.tradingview.com/pine-facade/translate"
# trailing slash matters: TradingView 301-redirects /chart-token to /chart-token/
CHART_TOKEN_URL = "https://www.tradingview.com/chart-token/"
LAYOUT_SOURCES_URL = "https://charts-storage.tradingview.com/charts-storage/get/layout"


def _new_async_client(*, timeout: float = 15.0) -> httpx.AsyncClient:
    """Default HTTP client for read-only TradingView endpoints.

    Auto-follows redirects: TradingView frequently 301s URLs like
    ``/chart-token`` → ``/chart-token/`` and we never need to inspect them.
    """
    return httpx.AsyncClient(timeout=timeout, follow_redirects=True)


class SymbolSearchResult(BaseModel):
    """One row from a symbol search."""

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    id: str = Field(description='"{exchange}:{symbol}"')
    symbol: str
    description: str | None = None
    type: str | None = None
    exchange: str | None = Field(default=None, description="Short exchange code")
    full_exchange: str | None = Field(default=None, description="Full exchange description")


class IndicatorSearchResult(BaseModel):
    """One row from an indicator search."""

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    pine_id: str = Field(alias="scriptIdPart")
    pine_version: str = Field(alias="version", default="last")
    name: str = Field(alias="scriptName")
    author: str | None = None
    image_url: str | None = Field(alias="imageUrl", default=None)
    access: str | None = None
    kind: str | None = None


@dataclass
class _HttpDefaults:
    user_agent: str = DEFAULT_USER_AGENT
    timeout: float = 15.0
    extra_headers: dict[str, str] = field(default_factory=dict)


def _build_headers(
    credentials: Credentials | None = None,
    extra: dict[str, str] | None = None,
    *,
    user_agent: str = DEFAULT_USER_AGENT,
) -> dict[str, str]:
    headers = {
        "User-Agent": user_agent,
        "Accept-Language": "en-US,en;q=0.9",
        "Origin": "https://www.tradingview.com",
        "Referer": "https://www.tradingview.com/",
    }
    if credentials is not None and not credentials.is_anonymous:
        cookie = gen_auth_cookies(credentials.sessionid, credentials.sessionid_sign)
        if cookie:
            headers["Cookie"] = cookie
    if extra:
        headers.update(extra)
    return headers


async def search_market(
    query: str,
    *,
    search_type: str = "",
    exchange: str | None = None,
    start: int = 0,
    client: httpx.AsyncClient | None = None,
    credentials: Credentials | None = None,
    user_agent: str = DEFAULT_USER_AGENT,
) -> list[SymbolSearchResult]:
    """Search TradingView's symbol database."""
    if exchange is None and ":" in query:
        prefix, _, rest = query.partition(":")
        exchange = prefix or None
        query = rest

    params = {
        "text": query.upper().replace(" ", "+").replace("%", "%25"),
        "search_type": search_type,
        "start": str(start),
    }
    if exchange:
        params["exchange"] = exchange

    headers = _build_headers(credentials, user_agent=user_agent)
    own = client is None
    http = client or _new_async_client()
    try:
        response = await http.get(SYMBOL_SEARCH_URL, params=params, headers=headers)
        response.raise_for_status()
        payload = response.json()
    finally:
        if own:
            await http.aclose()

    results: list[SymbolSearchResult] = []
    for raw in payload.get("symbols", []):
        prefix = raw.get("prefix") or raw.get("exchange") or ""
        symbol = raw.get("symbol") or ""
        results.append(
            SymbolSearchResult(
                id=f"{prefix}:{symbol}" if prefix else symbol,
                symbol=symbol,
                description=raw.get("description"),
                type=raw.get("type"),
                exchange=raw.get("prefix"),
                full_exchange=raw.get("exchange"),
            )
        )
    return results


async def search_indicator(
    query: str,
    *,
    client: httpx.AsyncClient | None = None,
    credentials: Credentials | None = None,
    user_agent: str = DEFAULT_USER_AGENT,
) -> list[IndicatorSearchResult]:
    """Search public Pine Script indicators by keyword."""
    headers = _build_headers(credentials, user_agent=user_agent)
    own = client is None
    http = client or _new_async_client()
    try:
        response = await http.get(
            INDICATOR_SEARCH_URL, params={"search": query}, headers=headers
        )
        response.raise_for_status()
        payload = response.json()
    finally:
        if own:
            await http.aclose()

    results: list[IndicatorSearchResult] = []
    access_map = {1: "open_source", 2: "closed_source", 3: "invite_only"}
    for raw in payload.get("results", []):
        author = raw.get("author") or {}
        extra = raw.get("extra") or {}
        results.append(
            IndicatorSearchResult(
                scriptIdPart=raw.get("scriptIdPart", ""),
                version=raw.get("version", "last"),
                scriptName=raw.get("scriptName", ""),
                author=author.get("username"),
                imageUrl=raw.get("imageUrl"),
                access=access_map.get(raw.get("access"), str(raw.get("access", ""))),
                kind=extra.get("kind"),
            )
        )
    return results


async def get_indicator(
    pine_id: str,
    pine_version: str = "last",
    *,
    client: httpx.AsyncClient | None = None,
    credentials: Credentials | None = None,
    user_agent: str = DEFAULT_USER_AGENT,
) -> PineIndicator:
    """Download a Pine Script indicator's metadata and return a :class:`PineIndicator`."""
    # Single-pass: matches the JS `id.replace(/ |%/g, '%25')` exactly.
    encoded_id = re.sub(r"[ %]", "%25", pine_id)
    url = f"{INDICATOR_TRANSLATE_URL}/{encoded_id}/{pine_version}"

    headers = _build_headers(credentials, user_agent=user_agent)
    own = client is None
    http = client or _new_async_client()
    try:
        response = await http.get(url, headers=headers)
        response.raise_for_status()
        payload = response.json()
    finally:
        if own:
            await http.aclose()

    if not payload.get("success") or "result" not in payload:
        raise TradingViewError(f"Pine indicator fetch failed: {payload.get('reason', 'unknown')}")

    result = payload["result"]
    meta = result.get("metaInfo", {})
    raw_inputs = meta.get("inputs", []) or []

    inputs: dict[str, PineInput] = {}
    for raw in raw_inputs:
        input_id = raw.get("id", "")
        if input_id in ("text", "pineId", "pineVersion"):
            continue
        inputs[input_id] = PineInput(
            name=raw.get("name", ""),
            type=raw.get("type", "text"),  # type: ignore[arg-type]
            value=raw.get("defval"),
            inline=raw.get("inline"),
            internal_id=raw.get("internalID"),
            tooltip=raw.get("tooltip"),
            is_hidden=raw.get("isHidden", False),
            is_fake=raw.get("isFake", False),
            options=raw.get("options"),
        )

    plots = _build_plot_names(meta)

    return PineIndicator(
        pine_id=meta.get("scriptIdPart", pine_id),
        pine_version=meta.get("pine") or meta.get("version", pine_version),
        description=meta.get("description", ""),
        short_description=meta.get("shortDescription", ""),
        script=result.get("ilTemplate", ""),
        inputs=inputs,
        plots=plots,
    )


def _build_plot_names(meta: dict[str, Any]) -> dict[str, str]:
    """Reproduce the JS naming logic: dedupe sanitised plot titles with ``_2``, ``_3``..."""
    styles = meta.get("styles") or {}
    plots: dict[str, str] = {}
    used: dict[str, int] = {}

    for plot_id, style in styles.items():
        if not isinstance(style, dict):
            continue
        title = style.get("title") or plot_id
        sanitised = "".join(c if c.isalnum() else "_" for c in str(title)).strip("_") or plot_id
        count = used.get(sanitised, 0) + 1
        used[sanitised] = count
        plots[plot_id] = sanitised if count == 1 else f"{sanitised}_{count}"

    for plot in meta.get("plots", []) or []:
        if not isinstance(plot, dict):
            continue
        plot_id = plot.get("id")
        target = plot.get("target")
        if plot_id and target and plot_id not in plots:
            plot_type = plot.get("type", "").lstrip("_") or "plot"
            plots[plot_id] = f"{target}_{plot_type}" if plot_type != "plot" else str(target)

    return plots


async def get_chart_token(
    layout_id: str,
    *,
    user_id: int = -1,
    credentials: Credentials | None = None,
    client: httpx.AsyncClient | None = None,
    user_agent: str = DEFAULT_USER_AGENT,
) -> str:
    """Resolve the JWT chart-token needed to read a layout from charts-storage.

    Public layouts work with ``user_id=-1`` and no credentials. Private layouts
    require both the owner's credentials *and* their numeric ``user_id`` (use
    :func:`tradingview_api.auth.fetch_user_info` to obtain it).
    """
    headers = _build_headers(credentials, user_agent=user_agent)
    params = {"image_url": layout_id, "user_id": str(user_id)}

    own = client is None
    http = client or _new_async_client()
    try:
        response = await http.get(CHART_TOKEN_URL, params=params, headers=headers)
        response.raise_for_status()
        payload = response.json()
    finally:
        if own:
            await http.aclose()

    token = payload.get("token")
    if not token:
        raise TradingViewError(
            f"chart-token request rejected (layout={layout_id!r}, user_id={user_id}): "
            f"{payload!r}"
        )
    return str(token)


async def get_layout_sources(
    layout_id: str,
    *,
    chart_id: str = "_shared",
    symbol: str = "",
    user_id: int = -1,
    credentials: Credentials | None = None,
    client: httpx.AsyncClient | None = None,
    user_agent: str = DEFAULT_USER_AGENT,
) -> dict[str, Any]:
    """Fetch the raw ``sources`` payload for a layout (drawings + chart metadata).

    Returns the full ``payload`` dict — typically contains ``sources`` (drawings
    keyed by ID) and chart-level metadata. Pass through the dict unmodified so
    you can inspect the actual TradingView shape, then narrow down later.
    """
    own = client is None
    http = client or _new_async_client()
    try:
        token = await get_chart_token(
            layout_id,
            user_id=user_id,
            credentials=credentials,
            client=http,
            user_agent=user_agent,
        )

        url = f"{LAYOUT_SOURCES_URL}/{layout_id}/sources"
        params = {"chart_id": chart_id, "jwt": token, "symbol": symbol}
        headers = _build_headers(credentials, user_agent=user_agent)

        response = await http.get(url, params=params, headers=headers)
        response.raise_for_status()
        payload = response.json()
    finally:
        if own:
            await http.aclose()

    inner = payload.get("payload")
    if inner is None:
        raise TradingViewError(
            f"layout sources empty (layout={layout_id!r}, chart_id={chart_id!r}): {payload!r}"
        )
    return inner if isinstance(inner, dict) else {"raw": inner}


_ = PineInputType  # re-export for type checkers
