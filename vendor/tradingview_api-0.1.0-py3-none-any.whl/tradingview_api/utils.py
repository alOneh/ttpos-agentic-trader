from __future__ import annotations

import secrets
import string

_SESSION_ID_ALPHABET = string.ascii_letters + string.digits
_SESSION_ID_LENGTH = 12


def gen_session_id(prefix: str = "xs") -> str:
    """Generate a TradingView session ID like ``xs_a1B2c3D4e5F6``.

    Uses ``secrets`` (cryptographic RNG) instead of ``Math.random()`` — same
    alphabet and length as the original JS implementation.
    """
    suffix = "".join(secrets.choice(_SESSION_ID_ALPHABET) for _ in range(_SESSION_ID_LENGTH))
    return f"{prefix}_{suffix}"


def gen_auth_cookies(sessionid: str | None = "", signature: str | None = "") -> str:
    """Build the ``Cookie`` header value used by TradingView HTTP requests.

    Mirrors ``genAuthCookies`` in the JS source: empty session ID returns ``""``;
    missing signature returns ``sessionid=...`` only.
    """
    if not sessionid:
        return ""
    if not signature:
        return f"sessionid={sessionid}"
    return f"sessionid={sessionid};sessionid_sign={signature}"
