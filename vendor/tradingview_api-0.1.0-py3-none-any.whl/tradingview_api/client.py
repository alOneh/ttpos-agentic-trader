from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from types import TracebackType
from typing import Any, Literal, Protocol

import websockets
from websockets.asyncio.client import ClientConnection
from websockets.exceptions import ConnectionClosed

from tradingview_api.auth import (
    ANONYMOUS_TOKEN,
    DEFAULT_USER_AGENT,
    Credentials,
    fetch_auth_token,
    resolve_credentials,
)
from tradingview_api.events import AsyncEventEmitter
from tradingview_api.exceptions import (
    ConnectionClosedError,
    SessionError,
    TradingViewError,
)
from tradingview_api.protocol import (
    Packet,
    format_packet,
    format_pong,
    parse_packet,
)

logger = logging.getLogger(__name__)

ServerName = Literal["data", "prodata", "widgetdata"]
ClientEvent = Literal["connected", "disconnected", "logged", "ping", "data", "error", "event"]


class SessionListener(Protocol):
    """Anything that can receive a packet routed by session ID."""

    def on_data(self, packet: Packet) -> None | Awaitable[None]: ...


class TradingViewClient:
    """Async WebSocket client for the TradingView data API.

    Usage::

        async with TradingViewClient() as client:
            quote = client.quote_session()
            ...

    Or manually::

        client = TradingViewClient()
        await client.connect()
        try:
            ...
        finally:
            await client.close()
    """

    def __init__(
        self,
        *,
        sessionid: str | None = None,
        sessionid_sign: str | None = None,
        auth_token: str | None = None,
        credentials: Credentials | None = None,
        server: ServerName = "data",
        location: str = "https://www.tradingview.com/",
        headers: dict[str, str] | None = None,
        user_agent: str = DEFAULT_USER_AGENT,
        use_env: bool = True,
    ) -> None:
        if credentials is None:
            credentials = resolve_credentials(
                sessionid=sessionid,
                sessionid_sign=sessionid_sign,
                auth_token=auth_token,
                use_env=use_env,
            )
        self._credentials = credentials
        self._url = (
            f"wss://{server}.tradingview.com/socket.io/websocket?from=chart&type=chart"
        )
        self._location = location
        self._user_agent = user_agent
        self._extra_headers: dict[str, str] = {
            "User-Agent": user_agent,
            "Origin": "https://www.tradingview.com",
            "Accept-Language": "en-US,en;q=0.9",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
            **(headers or {}),
        }

        self._ws: ClientConnection | None = None
        self._connected = False
        self._logged = False
        self._closing = False

        self._sessions: dict[str, SessionListener] = {}
        # Created lazily inside connect() so it binds to the running loop.
        self._send_queue: asyncio.Queue[str] | None = None
        self._tasks: list[asyncio.Task[None]] = []
        # Side-tasks (e.g. close-on-error) tracked separately so close() doesn't gather itself.
        self._side_tasks: set[asyncio.Task[None]] = set()
        self._events = AsyncEventEmitter()
        self._send_queue_maxsize = 1024

    @classmethod
    def from_browser(
        cls,
        browser: str = "chrome",
        domain: str = "tradingview.com",
        **kwargs: Any,
    ) -> TradingViewClient:
        creds = Credentials.from_browser(browser=browser, domain=domain)
        return cls(credentials=creds, **kwargs)

    def quote_session(
        self,
        *,
        fields: str | None = "all",
        custom_fields: list[str] | None = None,
    ) -> Any:
        """Create a new :class:`~tradingview_api.sessions.QuoteSession` on this client."""
        from tradingview_api.sessions.quote import QuoteSession

        return QuoteSession(self, fields=fields, custom_fields=custom_fields)  # type: ignore[arg-type]

    def chart_session(self) -> Any:
        """Create a new :class:`~tradingview_api.sessions.ChartSession` on this client."""
        from tradingview_api.sessions.chart import ChartSession

        return ChartSession(self)

    @property
    def is_connected(self) -> bool:
        return self._connected and self._ws is not None

    @property
    def is_logged(self) -> bool:
        return self._logged

    @property
    def credentials(self) -> Credentials:
        return self._credentials

    def on(self, event: ClientEvent, listener: Callable[..., Any]) -> Callable[..., Any]:
        """Register a callback for a client-level event.

        Events: ``connected``, ``disconnected``, ``logged``, ``ping``,
        ``data``, ``error``, ``event``.

        Returns ``listener`` so the method can be used as a decorator::

            @client.on("disconnected")
            def handle_disconnect():
                print("ws closed")
        """
        return self._events.on(event, listener)

    def once(self, event: ClientEvent, listener: Callable[..., Any]) -> Callable[..., Any]:
        """Like :meth:`on` but the listener fires at most once."""
        return self._events.once(event, listener)

    def off(self, event: ClientEvent, listener: Callable[..., Any]) -> None:
        """Remove a previously registered listener."""
        self._events.off(event, listener)

    def register_session(self, session_id: str, listener: SessionListener) -> None:
        if session_id in self._sessions:
            logger.warning("Session %s already registered, replacing listener", session_id)
        self._sessions[session_id] = listener

    def unregister_session(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)

    def send(self, msg_type: str, params: list[Any] | None = None) -> None:
        """Queue a packet for sending."""
        if self._closing:
            raise ConnectionClosedError("Client is closing")
        if self._send_queue is None:
            raise ConnectionClosedError("Client not connected; call connect() first")
        wire = format_packet({"m": msg_type, "p": params or []})
        self._send_queue.put_nowait(wire)

    async def connect(self) -> None:
        """Open the WebSocket and start the recv/send loops."""
        if self._ws is not None:
            raise TradingViewError("Client already connected")

        token = await self._resolve_auth_token()

        # Bind queue to the running loop now.
        self._send_queue = asyncio.Queue(maxsize=self._send_queue_maxsize)

        logger.debug("Connecting to %s", self._url)
        self._ws = await websockets.connect(
            self._url,
            additional_headers=self._extra_headers,
            user_agent_header=self._user_agent,
            max_size=2**24,
        )
        try:
            self._connected = True
            self._events.emit("connected")

            # The auth token packet must be the very first packet on the wire.
            auth_packet = format_packet({"m": "set_auth_token", "p": [token]})
            await self._ws.send(auth_packet)
            self._logged = True

            self._tasks = [
                asyncio.create_task(self._recv_loop(), name="tv-recv"),
                asyncio.create_task(self._send_loop(), name="tv-send"),
            ]
        except Exception:
            # Half-open WS would leak otherwise.
            try:
                await self._ws.close()
            except Exception:
                logger.debug("Error closing WS during failed connect", exc_info=True)
            self._ws = None
            self._connected = False
            self._logged = False
            raise

    async def close(self) -> None:
        """Cancel loops and close the WebSocket. Idempotent."""
        if self._closing:
            return
        self._closing = True

        for task in self._tasks:
            task.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()

        if self._ws is not None:
            try:
                await self._ws.close()
            except Exception:
                logger.exception("Error closing WebSocket")
            self._ws = None

        was_connected = self._connected
        self._connected = False
        self._logged = False
        self._send_queue = None
        # Single source of truth for the disconnected event.
        if was_connected:
            self._events.emit("disconnected")

    async def __aenter__(self) -> TradingViewClient:
        await self.connect()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.close()

    async def _resolve_auth_token(self) -> str:
        if self._credentials.is_anonymous:
            return ANONYMOUS_TOKEN
        if self._credentials.auth_token:
            return self._credentials.auth_token
        assert self._credentials.sessionid is not None
        return await fetch_auth_token(
            self._credentials.sessionid,
            self._credentials.sessionid_sign,
            location=self._location,
            user_agent=self._user_agent,
        )

    async def _recv_loop(self) -> None:
        assert self._ws is not None
        try:
            async for raw in self._ws:
                if isinstance(raw, bytes):
                    raw = raw.decode("utf-8")
                self._handle_frames(parse_packet(raw))
        except ConnectionClosed:
            logger.info("WebSocket closed by remote")
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Unhandled error in recv loop")
            self._events.emit("error", "recv_loop_failure")
        finally:
            # If the remote dropped us (not a user-initiated close), trigger close()
            # which will emit `disconnected` exactly once.
            if not self._closing:
                self._spawn_close("recv-loop-exit")

    async def _send_loop(self) -> None:
        assert self._ws is not None
        assert self._send_queue is not None
        try:
            while not self._closing:
                wire = await self._send_queue.get()
                try:
                    await self._ws.send(wire)
                    logger.debug(">> %s", wire)
                except ConnectionClosed:
                    logger.warning("Send failed: connection closed; dropping packet")
                    return
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Unhandled error in send loop")
            self._events.emit("error", "send_loop_failure")

    def _handle_frames(self, frames: list[Packet | int]) -> None:
        for frame in frames:
            logger.debug("<< %r", frame)
            if isinstance(frame, int):
                self._handle_ping(frame)
                continue

            msg_type = frame.get("m")
            if msg_type == "protocol_error":
                self._events.emit("error", SessionError("protocol_error", packet=frame))
                self._spawn_close("protocol-error")
                continue

            if msg_type and "p" in frame:
                params = frame["p"]
                session_id = params[0] if isinstance(params, list) and params else None
                if session_id and session_id in self._sessions:
                    self._dispatch_to_session(session_id, frame)
                    continue

            self._events.emit("data", frame)

    def _handle_ping(self, ping: int) -> None:
        pong = format_pong(ping)
        if self._send_queue is not None:
            self._send_queue.put_nowait(pong)
        self._events.emit("ping", ping)

    def _spawn_close(self, reason: str) -> None:
        """Schedule close() outside _tasks so close() doesn't gather itself."""
        if self._closing:
            return
        task = asyncio.create_task(self.close(), name=f"tv-close-{reason}")
        self._side_tasks.add(task)
        task.add_done_callback(self._on_side_task_done)

    def _on_side_task_done(self, task: asyncio.Task[Any]) -> None:
        self._side_tasks.discard(task)
        if task.cancelled():
            return
        exc = task.exception()
        if exc is not None:
            logger.error("Side task %s raised", task.get_name(), exc_info=exc)

    def _dispatch_to_session(self, session_id: str, packet: Packet) -> None:
        listener = self._sessions[session_id]
        try:
            result = listener.on_data(packet)
        except Exception:
            logger.exception("Session %s listener raised", session_id)
            return
        if asyncio.iscoroutine(result):
            task = asyncio.create_task(result, name=f"session-{session_id}")
            task.add_done_callback(_log_session_task_exception(session_id))


def _log_session_task_exception(session_id: str) -> Callable[[asyncio.Task[Any]], None]:
    def _cb(task: asyncio.Task[Any]) -> None:
        if task.cancelled():
            return
        exc = task.exception()
        if exc is not None:
            logger.error("Session %s task raised", session_id, exc_info=exc)

    return _cb
