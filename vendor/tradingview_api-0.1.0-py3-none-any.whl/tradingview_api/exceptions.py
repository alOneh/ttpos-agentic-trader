from __future__ import annotations


class TradingViewError(Exception):
    """Base class for all errors raised by tradingview_api."""


class ProtocolError(TradingViewError):
    """Raised when an incoming WebSocket frame cannot be parsed."""


class ConnectionClosedError(TradingViewError):
    """Raised when an operation is attempted on a closed connection."""


class AuthError(TradingViewError):
    """Raised when authentication with TradingView fails."""


class SessionError(TradingViewError):
    """Raised when a session-level error packet is received from TradingView."""

    def __init__(self, message: str, *, packet: dict | None = None) -> None:
        super().__init__(message)
        self.packet = packet
