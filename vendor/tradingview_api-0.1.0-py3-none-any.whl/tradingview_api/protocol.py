from __future__ import annotations

import base64
import io
import json
import logging
import re
import zipfile
from typing import Any, TypeAlias

from tradingview_api.exceptions import ProtocolError

logger = logging.getLogger(__name__)

Packet: TypeAlias = dict[str, Any]
"""A normal TradingView data packet, e.g. ``{"m": "qsd", "p": [...]}``."""

ParsedFrame: TypeAlias = Packet | int
"""A parsed frame element: a data packet (dict) or a ping number (int)."""

_HEARTBEAT_RX = re.compile(r"~h~")
_SPLITTER_RX = re.compile(r"~m~\d+~m~")


def parse_packet(raw: str) -> list[ParsedFrame]:
    """Parse a raw TradingView WebSocket frame.

    The wire format interleaves data packets ``~m~{LEN}~m~{JSON}`` and ping
    markers ``~h~{N}``. We strip the ``~h~`` markers first so a bare ``~h~{N}``
    parses as the integer ``N`` (which the client recognizes as a ping to be
    echoed back).

    Returns a list mixing :class:`dict` (data packets) and :class:`int` (pings).
    Malformed JSON fragments are skipped with a warning rather than raising,
    matching the JS implementation's tolerant behavior.
    """
    cleaned = _HEARTBEAT_RX.sub("", raw)
    parts = _SPLITTER_RX.split(cleaned)

    parsed: list[ParsedFrame] = []
    for part in parts:
        if not part:
            continue
        try:
            obj = json.loads(part)
        except json.JSONDecodeError:
            logger.warning("Cannot parse WS fragment: %r", part)
            continue
        if isinstance(obj, (dict, int)):
            parsed.append(obj)
        else:
            logger.warning("Unexpected WS fragment type %s: %r", type(obj).__name__, obj)
    return parsed


def format_packet(packet: Packet | str) -> str:
    """Wrap a packet in the ``~m~{LEN}~m~{MSG}`` envelope.

    ``LEN`` is computed in UTF-16 code units to match JavaScript's
    ``String.length``, which is what the TradingView server expects (the
    reference client is written in JS).
    """
    msg = json.dumps(packet, separators=(",", ":")) if isinstance(packet, dict) else packet
    return f"~m~{_utf16_length(msg)}~m~{msg}"


def format_pong(ping_number: int) -> str:
    """Build a heartbeat reply for the given ping number."""
    return format_packet(f"~h~{ping_number}")


def parse_compressed(data: str) -> Any:
    """Decode a base64+ZIP payload sent by TradingView (used for some study results).

    The archive contains a single entry with an empty name; we read whichever
    entry is present rather than relying on its name.
    """
    raw_bytes = base64.b64decode(data)
    try:
        with zipfile.ZipFile(io.BytesIO(raw_bytes)) as archive:
            names = archive.namelist()
            if not names:
                raise ProtocolError("Compressed payload has no entries")
            content = archive.read(names[0])
    except zipfile.BadZipFile as exc:
        raise ProtocolError(f"Invalid ZIP payload: {exc}") from exc

    return json.loads(content.decode("utf-8"))


def _utf16_length(s: str) -> int:
    """Number of UTF-16 code units, matching JavaScript's ``String.length``."""
    return sum(2 if ord(ch) > 0xFFFF else 1 for ch in s)
