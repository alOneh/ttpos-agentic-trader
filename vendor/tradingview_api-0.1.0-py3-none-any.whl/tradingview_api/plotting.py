"""Chart rendering helpers built on mplfinance, with a TradingView-inspired theme.

Only available if you installed the ``[plot]`` extra::

    uv sync --extra plot
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import matplotlib.figure
    import pandas as pd

    from tradingview_api.models.ohlcv import OHLCVResult

logger = logging.getLogger(__name__)


TV_GREEN = "#26a69a"
TV_RED = "#ef5350"
TV_BACKGROUND = "#131722"
TV_GRID = "#1e222d"
TV_AXIS = "#787b86"
TV_TEXT = "#d1d4dc"


def _require_mplfinance() -> Any:
    try:
        import mplfinance as mpf
    except ImportError as exc:
        raise ImportError(
            "mplfinance is required for plotting. Install with: uv sync --extra plot"
        ) from exc
    return mpf


def tradingview_style() -> Any:
    """Return an ``mplfinance`` style mimicking TradingView's dark theme."""
    mpf = _require_mplfinance()
    market_colors = mpf.make_marketcolors(
        up=TV_GREEN,
        down=TV_RED,
        edge={"up": TV_GREEN, "down": TV_RED},
        wick={"up": TV_GREEN, "down": TV_RED},
        volume={"up": TV_GREEN, "down": TV_RED},
        ohlc="inherit",
    )
    return mpf.make_mpf_style(
        base_mpf_style="nightclouds",
        marketcolors=market_colors,
        facecolor=TV_BACKGROUND,
        edgecolor=TV_BACKGROUND,
        figcolor=TV_BACKGROUND,
        gridcolor=TV_GRID,
        gridstyle="-",
        rc={
            "axes.labelcolor": TV_TEXT,
            "axes.edgecolor": TV_AXIS,
            "xtick.color": TV_AXIS,
            "ytick.color": TV_AXIS,
            "text.color": TV_TEXT,
            "font.size": 9,
        },
    )


def _resolve_dataframe(data: pd.DataFrame | OHLCVResult) -> pd.DataFrame:
    from tradingview_api.models.ohlcv import OHLCVResult

    if isinstance(data, OHLCVResult):
        return data.to_dataframe()
    return data


def plot_candles(
    data: pd.DataFrame | OHLCVResult,
    *,
    title: str | None = None,
    volume: bool = True,
    indicators: list[pd.DataFrame | dict[str, Any]] | None = None,
    style: Any = None,
    figsize: tuple[float, float] = (14, 7),
    chart_type: str = "candle",
    return_fig: bool = True,
) -> matplotlib.figure.Figure:
    """Render a TradingView-style candle chart from an OHLCV DataFrame or result.

    ``indicators`` can be a list of either:
    - ``pd.DataFrame`` (each column will be plotted as an overlay line on the price panel)
    - dicts with mplfinance ``addplot`` kwargs (e.g. ``{"data": df, "panel": 1}``)
    """
    mpf = _require_mplfinance()

    df = _resolve_dataframe(data)
    if df.empty:
        raise ValueError("Cannot plot an empty DataFrame")

    plot_style = style if style is not None else tradingview_style()

    addplots = []
    if indicators:
        for ind in indicators:
            if hasattr(ind, "columns"):
                df_ind = ind
                for col in df_ind.columns:
                    addplots.append(
                        mpf.make_addplot(df_ind[col], color=TV_TEXT, width=1.0)
                    )
            elif isinstance(ind, dict):
                addplots.append(mpf.make_addplot(**ind))

    plot_kwargs: dict[str, Any] = {
        "type": chart_type,
        "style": plot_style,
        "volume": volume,
        "title": title or "",
        "figsize": figsize,
        "returnfig": True,
        "warn_too_much_data": 10000,
    }
    if addplots:
        plot_kwargs["addplot"] = addplots
    fig, _axes = mpf.plot(df, **plot_kwargs)
    if return_fig:
        return fig
    return _axes


def save_chart_png(
    data: pd.DataFrame | OHLCVResult,
    path: str | Path,
    *,
    title: str | None = None,
    volume: bool = True,
    indicators: list[pd.DataFrame | dict[str, Any]] | None = None,
    style: Any = None,
    figsize: tuple[float, float] = (14, 7),
    dpi: int = 150,
    chart_type: str = "candle",
) -> Path:
    """Render and save a chart as a PNG (one-shot helper for screenshots)."""
    fig = plot_candles(
        data,
        title=title,
        volume=volume,
        indicators=indicators,
        style=style,
        figsize=figsize,
        chart_type=chart_type,
    )
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=dpi, facecolor=fig.get_facecolor(), bbox_inches="tight")
    return output
