from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class QuoteData(BaseModel):
    """A snapshot of quote fields for a single symbol.

    The TradingView quote stream sends sparse updates (only the fields that
    changed). This model accepts arbitrary extra fields so unmodelled fields
    are still accessible via attribute or :meth:`model_dump`. The most common
    fields are typed for IDE autocompletion.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    last_price: float | None = Field(default=None, alias="lp")
    change: float | None = Field(default=None, alias="ch")
    change_percent: float | None = Field(default=None, alias="chp")
    volume: float | None = Field(default=None, alias="volume")
    bid: float | None = Field(default=None, alias="bid")
    ask: float | None = Field(default=None, alias="ask")
    high_price: float | None = Field(default=None, alias="high_price")
    low_price: float | None = Field(default=None, alias="low_price")
    open_price: float | None = Field(default=None, alias="open_price")
    prev_close_price: float | None = Field(default=None, alias="prev_close_price")
    last_price_time: int | None = Field(default=None, alias="lp_time")
    description: str | None = Field(default=None, alias="description")
    short_name: str | None = Field(default=None, alias="short_name")
    pro_name: str | None = Field(default=None, alias="pro_name")
    exchange: str | None = Field(default=None, alias="exchange")
    currency_code: str | None = Field(default=None, alias="currency_code")
    type: str | None = Field(default=None, alias="type")
    update_mode: str | None = Field(default=None, alias="update_mode")

    def merged_with(self, update: dict[str, Any]) -> QuoteData:
        """Return a new ``QuoteData`` with ``update`` fields merged in.

        Uses ``model_copy(update=...)`` for a single-pass field assignment, which
        is much cheaper than ``model_dump`` + ``model_validate`` on the
        high-frequency quote stream. Aliases in ``update`` (e.g. ``"lp"``) are
        translated to model field names so the typed accessors stay in sync.
        """
        if not update:
            return self
        # Map TradingView aliases to our typed field names where possible.
        alias_to_field = {
            field.alias: name
            for name, field in type(self).model_fields.items()
            if field.alias is not None
        }
        translated: dict[str, Any] = {}
        for key, value in update.items():
            translated[alias_to_field.get(key, key)] = value
        return self.model_copy(update=translated)
