from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, ConfigDict, Field

if TYPE_CHECKING:
    import pandas as pd


class Period(BaseModel):
    """One OHLCV candle."""

    model_config = ConfigDict(frozen=True)

    time: int = Field(description="UNIX timestamp in seconds")
    open: float
    high: float
    low: float
    close: float
    volume: float

    @property
    def datetime(self) -> datetime:
        return datetime.fromtimestamp(self.time, tz=UTC)

    @classmethod
    def from_wire(cls, values: list[float]) -> Period:
        """Build from the raw ``[t, o, h, l, c, v]`` array sent by TradingView."""
        return cls(
            time=int(values[0]),
            open=float(values[1]),
            high=float(values[2]),
            low=float(values[3]),
            close=float(values[4]),
            volume=float(values[5]),
        )


class MarketInfo(BaseModel):
    """Symbol metadata returned by ``symbol_resolved``."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    series_id: str | None = None
    name: str | None = None
    full_name: str | None = None
    pro_name: str | None = None
    description: str | None = None
    short_description: str | None = None
    exchange: str | None = None
    listed_exchange: str | None = None
    provider_id: str | None = None
    currency_id: str | None = None
    currency_code: str | None = None
    base_currency: str | None = None
    base_currency_id: str | None = None
    type: str | None = None
    session: str | None = None
    timezone: str | None = None
    pricescale: float | None = None
    pointvalue: float | None = None
    minmov: float | None = None
    minmove2: float | None = None
    has_intraday: bool | None = None
    has_extended_hours: bool | None = None
    is_tradable: bool | None = None
    fractional: bool | None = None


class OHLCVResult(BaseModel):
    """A snapshot of OHLCV periods plus the symbol info, ready for analysis."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    symbol: str
    timeframe: str
    info: MarketInfo
    periods: list[Period]

    def to_dataframe(self) -> pd.DataFrame:
        """Return a DataFrame indexed by UTC datetime with OHLCV columns.

        Sorted ascending by time so it plots correctly in matplotlib/mplfinance.
        """
        import pandas as pd

        if not self.periods:
            return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])

        sorted_periods = sorted(self.periods, key=lambda p: p.time)
        df = pd.DataFrame(
            [
                {
                    "open": p.open,
                    "high": p.high,
                    "low": p.low,
                    "close": p.close,
                    "volume": p.volume,
                }
                for p in sorted_periods
            ],
            index=pd.to_datetime([p.time for p in sorted_periods], unit="s", utc=True),
        )
        df.index.name = "time"
        return df

    @property
    def df(self) -> pd.DataFrame:
        return self.to_dataframe()

    def __len__(self) -> int:
        return len(self.periods)


def merge_periods(existing: dict[int, Period], updates: list[dict[str, Any]]) -> None:
    """In-place merge of incoming ``s`` array entries into the period dict."""
    for entry in updates:
        values = entry.get("v")
        if not values or len(values) < 6:
            continue
        period = Period.from_wire(values)
        existing[period.time] = period
